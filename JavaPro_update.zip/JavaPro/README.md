# JavaPro - Android Performance Optimizer

**Package:** `com.javapro.app`  
**Version:** 3.1.0  
**Min SDK:** 28 (Android 9)  
**Target SDK:** 34 (Android 14)

## Features

### Home
- Live system stats (CPU, RAM, Temp)
- Banner with status indicator
- Quick access: App Profiles, System Monitor
- Shizuku connection status
- Tools: App Analyzer, Network Monitor, Storage Cleaner, Wakelock Analyzer
- Support links: Donate, WhatsApp, Telegram, Report Bug

### GameBoost
- Device Spoof (ASUS ROG, RedMagic, Samsung, etc.)
- Benchmark (CPU Multi/Single, best score tracking)
- Custom Crosshair (Classic/Dot/Circle overlay)
- Ping Test (Singapore/Tokyo/Mumbai/Sydney/Frankfurt)
- Deep Freeze (freeze background apps)
- FPS Monitor overlay
- Debloat via Shizuku
- FPS Stabilizer
- Process Manager

### Advanced
- VM Tweaks: Swappiness, Cache Pressure, Dirty Ratio, Page Cluster
- ZRAM Algorithm: LZ4/ZSTD/LZO/Off
- CPU Governor
- Read Ahead: 128KB
- TCP Congestion: cubic
- Apply on Boot toggle

### Settings
- Google Account profile
- Language selector
- Coin Store
- Shizuku Terminal
- Display Resolution
- Color Calibration
- Reset All Settings
- App info (version, security patch, SDK target)

## Setup

### 1. Google Sign-In
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create project → Add Android app (`com.javapro.app`)
3. Download `google-services.json` → place in `/app/`
4. In Firebase Console → Authentication → Sign-in methods → Enable Google
5. Copy your **Web Client ID** to `strings.xml` → `default_web_client_id`

### 2. Shizuku
- User needs [Shizuku app](https://shizuku.rikka.app/) installed & running

## Build via GitHub Actions
Push to `main` → Actions auto-builds debug APK → download from Artifacts

## Tech Stack
- Java / Kotlin hybrid
- AndroidX Navigation Component
- Biometric: `androidx.biometric:biometric:1.1.0`
- Google Sign-In: `play-services-auth:20.7.0`
- Shizuku API v13
- Material Design 3
- AMOLED dark theme (#0A0A0A bg, #1C1C1E cards)
