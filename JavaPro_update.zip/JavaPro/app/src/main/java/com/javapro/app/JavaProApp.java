package com.javapro.app;

import android.app.Application;

public class JavaProApp extends Application {
    
    private static JavaProApp instance;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }
    
    public static JavaProApp getInstance() {
        return instance;
    }
}
