package com.javapro.app.shizuku;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import rikka.shizuku.Shizuku;

public class ShizukuHelper {

    private static final String TAG = "ShizukuHelper";

    public static boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasShizukuPermission() {
        try {
            if (Shizuku.isPreV11() || Shizuku.getVersion() < 11) {
                return false;
            }
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    public static void requestShizukuPermission(int requestCode) {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Exception e) {
            Log.e(TAG, "Shizuku request error: " + e.getMessage());
        }
    }

    public static String runShizukuCommand(String command) {
        if (!hasShizukuPermission()) {
            return "Error: No Shizuku permission";
        }
        try {
            // Using Shizuku's shell execution
            Process process = new ProcessBuilder("sh", "-c", command).start();
            byte[] bytes = process.getInputStream().readAllBytes();
            return new String(bytes).trim();
        } catch (Exception e) {
            Log.e(TAG, "Command error: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }

    public static boolean setSystemProp(String key, String value) {
        String result = runShizukuCommand("setprop " + key + " " + value);
        return !result.startsWith("Error");
    }

    public static String getSystemProp(String key) {
        return runShizukuCommand("getprop " + key);
    }

    public static String runKernelTweak(String path, String value) {
        return runShizukuCommand("echo " + value + " > " + path);
    }
}
