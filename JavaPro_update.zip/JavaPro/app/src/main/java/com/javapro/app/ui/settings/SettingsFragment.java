package com.javapro.app.ui.settings;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.javapro.app.R;
import com.javapro.app.ui.login.LoginActivity;
import com.javapro.app.utils.SessionManager;

public class SettingsFragment extends Fragment {

    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sessionManager = new SessionManager(requireContext());

        // Set profile info from session
        TextView tvName = view.findViewById(R.id.tv_profile_name);
        TextView tvEmail = view.findViewById(R.id.tv_profile_email);

        String name = sessionManager.getUserName();
        String email = sessionManager.getUserEmail();

        if (!name.isEmpty()) tvName.setText(name);
        if (!email.isEmpty()) tvEmail.setText(email);

        view.findViewById(R.id.item_language).setOnClickListener(v ->
            Toast.makeText(getContext(), "Language: English", Toast.LENGTH_SHORT).show());

        view.findViewById(R.id.item_coin_store).setOnClickListener(v ->
            Toast.makeText(getContext(), "Coin Store coming soon!", Toast.LENGTH_SHORT).show());

        view.findViewById(R.id.item_terminal).setOnClickListener(v ->
            Toast.makeText(getContext(), "Shizuku Terminal", Toast.LENGTH_SHORT).show());

        view.findViewById(R.id.item_display_res).setOnClickListener(v ->
            Toast.makeText(getContext(), "Display Resolution", Toast.LENGTH_SHORT).show());

        view.findViewById(R.id.item_color_calib).setOnClickListener(v ->
            Toast.makeText(getContext(), "Color Calibration", Toast.LENGTH_SHORT).show());

        view.findViewById(R.id.item_reset).setOnClickListener(v ->
            showResetDialog());
    }

    private void showResetDialog() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Reset All Settings")
            .setMessage("This will clear all your settings and log you out. Continue?")
            .setPositiveButton("Reset", (dialog, which) -> {
                sessionManager.logout();
                startActivity(new Intent(getActivity(), LoginActivity.class));
                requireActivity().finish();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
