package com.javapro.app.ui.gameboost;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.javapro.app.R;

public class GameBoostFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gameboost, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.btn_device_spoof).setOnClickListener(v ->
            showFeature("Device Spoof - Select brand: ASUS ROG, RedMagic, Samsung..."));

        view.findViewById(R.id.btn_benchmark).setOnClickListener(v ->
            showFeature("Benchmark - Best Score: 12921"));

        view.findViewById(R.id.btn_crosshair).setOnClickListener(v ->
            showFeature("Custom Crosshair - Classic Cross/Dot/Circle+Dot"));

        view.findViewById(R.id.btn_ping_test).setOnClickListener(v ->
            showFeature("Ping Test - Singapore/Tokyo/Mumbai/Sydney/Frankfurt"));

        view.findViewById(R.id.btn_deep_freeze).setOnClickListener(v ->
            showFeature("Deep Freeze - Freeze background apps"));

        view.findViewById(R.id.btn_fps_monitor).setOnClickListener(v ->
            showFeature("FPS Monitor - Real-time overlay"));

        view.findViewById(R.id.btn_debloat).setOnClickListener(v ->
            showFeature("Debloat - Remove bloatware via Shizuku"));

        view.findViewById(R.id.btn_fps_stabilizer).setOnClickListener(v ->
            showFeature("FPS Stabilizer - Lock frame rate"));

        view.findViewById(R.id.btn_process_manager).setOnClickListener(v ->
            showFeature("Process Manager - Manage running processes"));
    }

    private void showFeature(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
}
